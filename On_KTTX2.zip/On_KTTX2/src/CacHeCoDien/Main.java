package CacHeCoDien;

import java.util.Scanner;

public class Main {

	//
	// e = x + k
	public static String caesarEncode(String strRoot, int k) {
		String strEncode = "";
		
		for(char c: strRoot.toCharArray())
			if(Character.isUpperCase(c))
				//97 - 97 + 2 + 97
				//*
				strEncode += (char)(((c - 'A') + k) % 26 + 'A');
		//Ví dụ c là ký B -> B - A = 1 + 2 = 3 ->  A + 3 = D 
			else if(Character.isLowerCase(c))
				strEncode += (char)((c - 'a' + k) % 26 + 'a');
			else
				strEncode += c;
		
		return strEncode;
	}
	
	public static String caesarDecryption(String strEncode, int k) {
		String strRoot = "";
		
		for(char c: strEncode.toCharArray())
			if(Character.isUpperCase(c))
				//97 - 97 + 2 + 97
				// *
				
				strRoot += (char)((c - 'A' - k + 26) % 26 + 'A');
			else if(Character.isLowerCase(c))
				strRoot += (char)((c - 'a' - k + 26) % 26 + 'a');
			else
				strRoot += c;
		
		return strRoot;
	}
	
	public static String vigenereEncode(String strRoot, String keyWord) {
		String strEncode = "";
		int m = keyWord.length(), j = 0;
		
		for(char c: strRoot.toCharArray()) {
			if(j == m)
				j = 0;
			if(Character.isUpperCase(c))
				strEncode += (char)(((c - 'A') + (keyWord.charAt(j) - 'A'))%26 + 'A');
			else if(Character.isLowerCase(c))
				strEncode += (char)(((c - 'a') + (keyWord.charAt(j) - 'a'))%26 + 'a');
			else
				strEncode += c;
			j++;
		}
		
		return strEncode;
	}
	
	public static String vigenereDecryption(String strEncode, String keyWord) {
		String strRoot = "";
		int m = keyWord.length(), j = 0;
		
		for(char c: strEncode.toCharArray()) {
			if(j == m)
				j = 0;
			if(Character.isUpperCase(c))
				strRoot += (char)(((c - 'A') - (keyWord.charAt(j) - 'A') + 26)%26 + 'A');
			else if(Character.isLowerCase(c))
				strRoot += (char)(((c - 'a') - (keyWord.charAt(j) - 'a') + 26)%26 + 'a');
			else
				strRoot += c;
			j++;
		}
		
		return strRoot;
	}
	//e = a*x + b
	public static String affineEncode(String strRoot, int a, int b) {
		String strEncode = "";
		
		for(char c: strRoot.toCharArray())
			if(Character.isUpperCase(c))
				strEncode += (char)((a*(c - 'A') + b)%26 + 'A');
			else if(Character.isLowerCase(c))
				strEncode += (char)((a*(c - 'a') + b)%26 + 'a');
			else
				strEncode += c;
		
		return strEncode;
	}
	
	//x = a^-1 * (e - b)
	public static String affineDecryption(String strEncode, int a, int b) {
		String strRoot = "";
		int aRe = 0;
		
		//Tìm a^-1
		for(int i = 1;i < 26;i++)
			if((i * a) % 26 == 1)
				aRe = i;
		
		
		for(char c: strEncode.toCharArray())
			if(Character.isUpperCase(c))
				strRoot += (char)((aRe * (c - 'A' - b + 26))%26 + 'A');
			else if(Character.isLowerCase(c))
				strRoot += (char)((aRe * (c - 'a' - b + 26))%26 + 'a');
			else 
				strRoot += c;
			
		return strRoot;
	}
	//x = a^-1 * (e - b)
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
//		System.out.print("Nhập bản rõ là:");
//		String strRoot = sc.nextLine();
//		System.out.print("Nhập k = ");
//		int k = sc.nextInt();
//		System.out.println("Sau khi mã hóa là:" + caesarEncode(strRoot, k));
//		System.out.println("Giải mã ngược là " + caesarDecryption(caesarEncode(strRoot, k), k) );
		
//		System.out.print("Nhập bản rõ là:");
//		String strRoot = sc.nextLine();
//		System.out.print("Nhập keyWord LÀ ");
//		String keyWord = sc.nextLine();
//		System.out.println("Sau khi mã hóa là:" + vigenereEncode(strRoot, keyWord));
//		System.out.println("Giải mã ngược là " + vigenereDecryption(vigenereEncode(strRoot, keyWord), keyWord));
		
		System.out.print("Nhập bản rõ là:");
		String strRoot = sc.nextLine();
		System.out.print("Nhập a = ");
		int a = sc.nextInt();
		System.out.print("Nhập b = ");
		int b = sc.nextInt();
		System.out.println("Sau khi mã hóa là:" + affineEncode(strRoot, a, b));
		System.out.println("Giải mã ngược là " + affineDecryption(affineEncode(strRoot, a, b), a, b));
	}
	
	
}
